package net.unknownclub.Sprintboottut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintBootTutApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintBootTutApplication.class, args);
	}

}
