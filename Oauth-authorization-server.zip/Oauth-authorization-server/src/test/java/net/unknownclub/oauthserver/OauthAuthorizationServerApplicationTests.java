package net.unknownclub.oauthserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthAuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
